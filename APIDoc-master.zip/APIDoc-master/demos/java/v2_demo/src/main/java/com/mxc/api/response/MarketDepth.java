package com.mxc.api.response;

import lombok.Data;

@Data
public class MarketDepth {

    private String price;

    private String quantity;
}
