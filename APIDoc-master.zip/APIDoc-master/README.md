Please visit the following links for the API documents and demos

### REST API V2 doc

- [https://mxcdevelop.github.io/APIDoc/](https://mxcdevelop.github.io/APIDoc/)

### REST API V1 doc

- [https://github.com/mxcdevelop/APIDoc/tree/master/api_doc_v1](https://github.com/mxcdevelop/APIDoc/tree/master/api_doc_v1)

### WebSocket doc

- [https://github.com/mxcdevelop/APIDoc/blob/master/websocket/websocket-api.md](https://github.com/mxcdevelop/APIDoc/blob/master/websocket/websocket-api.md)

### REST API demos

- [https://github.com/mxcdevelop/APIDoc/tree/master/demos](https://github.com/mxcdevelop/APIDoc/tree/master/demos)

### WebSocket demos

- [https://github.com/mxcdevelop/APIDoc/tree/master/websocket](https://github.com/mxcdevelop/APIDoc/tree/master/websocket)